

<?php 

use App\Models\Commanmodel;
 $commanmodel = new Commanmodel();
 
 ?><section><img src="<?php echo base_url('assets/frontend/'); ?>/assets/img/store.jpg" style="width:100%"></section>
	<div class="breadcrumbs-area mb-50">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="breadcrumbs-menu">
						<ul>
							<li><a href="#">Home</a></li>
							<li><a href="#" class="active">shop</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- breadcrumbs-area-end -->
	<!-- shop-main-area-start -->
<div class="product-area pt-70 xs-mb">
  <div class="container">

    <div style="margin-bottom: 80px">

     
          <div class="row ajax_list"> 



          </div>
        
    </div>
   
  </div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>




<script>
$(document).ready(function() {
    // Initialize the slider
  /*  $(".slider-range").slider({
        range: true,
        min: 500,
        max: 500000,
        values: [500, 100000],
        slide: function(event, ui) {
            $(".amount").val("Rs" + ui.values[0] + " - Rs" + ui.values[1]);
            $('#minprice').val(ui.values[0]);
            $('#maxprice').val(ui.values[1]);
            ajax_list(1);
        }
    });

    // Set initial amount value
    $(".amount").val("Rs" + $(".slider-range").slider("values", 0) +
        " - Rs" + $(".slider-range").slider("values", 1));
    
    // Set initial minprice and maxprice values
    $('#minprice').val($(".slider-range").slider("values", 0));
    $('#maxprice').val($(".slider-range").slider("values", 1));
*/
    // Initial ajax call
    ajax_list(1);

    // Event listeners
    $('.common_selector_change').on('change', function() {
        ajax_list(1);
    });

    $('.common_selector').click(function() {
        ajax_list(1);
    });
    
  
     
    

    // Function to fetch and filter data
    function ajax_list(page) {
        var action = 'fetch_data';
          var mainid = '<?php echo $mainid; ?>';
        var id = '<?php echo $id; ?>';
        var search = $('#search').val();
        var list = '<?php echo $url; ?>';
        var collection = '<?php echo $collection; ?>';
         var minprice =  $('#min_price').val();
          var maxprice =  $('#max_price').val();
          var shortby =  $('#orderby').val();
        
        $.ajax({
            url: "<?php echo base_url('ajax_list'); ?>/" + page,
            method: "POST",
            dataType: "JSON",
            data: {action: action,mainid:mainid, id: id, list: list, search: search, collection: collection,minprice:minprice,maxprice:maxprice,shortby:shortby},
            beforeSend: function() {
                // Add loading animation or something if needed
            },
            success: function(data) {
                $('#item_total').html(data.item_total);
                $('.ajax_list').html(data.product_list);
                 $('.headoutput').html(data.headoutput);
                
                $('#pagination_link').html(data.pagination_link);
            }
        });
    }
    
    
    $('.pricecheck').click(function() {
       min = $(this).attr('data-min');
        max = $(this).attr('data-max');
        $('#min_price').val(min);
        $('#max_price').val(max);
         ajax_list(1);
    });
    
 $(document).on('click', '.pagination-link', function(e) {
    e.preventDefault();
    var page = $(this).data('page'); // This should be a number like 1, 2, 3...
    
    // If `page` is a full URL like "?page=5", extract just the number
    if (typeof page === 'string' && page.includes('page=')) {
        page = page.split('page=')[1];
    }

    ajax_list(page);
});


    // Function to get selected filters
    function get_filter_production(class_name) {
        var filter = [];
        $('.' + class_name + ':checked').each(function() {
            filter.push($(this).val());
        });
        return filter;
    }
});

</script>