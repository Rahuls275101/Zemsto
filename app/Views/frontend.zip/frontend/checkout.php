<!-- breadcrumbs-area-start -->
<style>button.btn {
    background: #f07c29 none repeat scroll 0 0;
    border: 2px solid #d6681b;
    border-radius: 4px;
    color: #fff;
    display: inline-block;
    font-size: 14px;
    font-weight: 400;
    line-height: 34px;
    margin-top: 8px;
    padding: 3px 15px;
    text-transform: none;
    font-family: 'Manrope', serif;
    font-weight: 600;
    text-decoration: none;
    /* box-shadow: 2px 2px 2px 2px #a8c0ba; */
    text-transform: capitalize;
}</style>
<div class="breadcrumbs-area mb-30">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs-menu">
                    <ul>
                        <li><a href="<?php echo base_url(''); ?>">Home</a></li>
                        <li><a href="#" class="active">Checkout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumbs-area-end -->

<!-- entry-header-area-start -->
<div class="entry-header-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="entry-header-title">
                    <h2>Checkout</h2>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- entry-header-area-end -->

<!-- coupon-area-area-start -->
<div class="coupon-area mb-70">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="coupon-accordion">
                    <h3>Returning customer? <span id="showlogin">Click here to login</span></h3>
                    <div class="coupon-content" id="checkout-login">
                        <div class="coupon-info">
                            <p>Please login your account.</p>
                            <form id="user_login" class="login-content">
                                <p>
                                    If you have shopped with us before, please enter your details below. If you are a new
                                    customer, please proceed to the Billing & Shipping section.
                                </p>

                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="checkout-form-list">
                                            <label>Username or email <span class="required">*</span></label>
                                            <input type="email" class="form-control" name="login_email" required>
                                            <p id="login_email_error" class="errors"></p>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="checkout-form-list">
                                            <label>Password <span class="required">*</span></label>
                                            <input type="password" class="form-control" name="login_password" required>
                                            <p id="login_password_error" class="errors"></p>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="user_login" value="Login">
                                <button type="submit" id="login_submit" class="btn theme-btn-2 btn-effect-2 text-uppercase">LOGIN</button>

                                <div class="form-footer mb-1">
                                    <div class="custom-control custom-checkbox mb-0 mt-0">
                                        <input type="checkbox" class="custom-control-input" id="lost-password">
                                        <label class="custom-control-label mb-0" for="lost-password">Remember me</label>
                                    </div>
                                    <a href="forgot-password.html" class="forget-password">Lost your password?</a>
                                </div>
                            </form>
                        </div>
                    </div>

                    <h3>Have a coupon? <span id="showcoupon">Click here to enter your code</span></h3>
                    <div class="coupon-checkout-content" id="checkout_coupon">
                        <div class="coupon-info">
                            <form action="#">
                                
                                <p class="checkout-coupon">
                                    <input type="text" id="coupon_code" placeholder="Coupon code" required>
                                    <button class="btn   applycoupon" type="submit">Apply Coupon</button>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- coupon-area-area-end -->

<!-- checkout-area-start -->
<div class="checkout-area mb-70">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <form action="<?php echo base_url('order-now'); ?>" class="form checkout-form" method="POST">
                    <div class="row">
                        <!-- Billing Details -->
                        <div class="col-lg-6 col-md-12 col-12">
                            <div class="checkbox-form">
                                <h3>Billing Details</h3>
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="checkout-form-list">
                                            <label>Name <abbr class="required" title="required">*</abbr></label>
                                            <input type="text" name="name" class="form-control">
                                            <div class="error-message" id="name-error"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="checkout-form-list">
                                            <label>Email <abbr class="required" title="required">*</abbr></label>
                                            <input type="email" name="email" class="form-control">
                                            <div class="error-message" id="email-error"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="checkout-form-list">
                                            <label>Phone <abbr class="required" title="required">*</abbr></label>
                                            <input type="text" name="phone" class="form-control">
                                            <div class="error-message" id="phone-error"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="checkout-form-list">
                                            <label>Pin Code <abbr class="required" title="required">*</abbr></label>
                                            <input type="text" name="pin_code" id="pinCode" class="form-control applypin">
                                            <div class="error-message" id="pin_code-error"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="checkout-form-list">
                                            <label>City <abbr class="required" title="required">*</abbr></label>
                                            <input type="text" name="city" class="form-control" required>
                                            <div class="error-message" id="city-error"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="checkout-form-list">
                                            <label>State <abbr class="required" title="required">*</abbr></label>
                                            <input type="text" name="state" class="form-control" required>
                                            <div class="error-message" id="state-error"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="checkout-form-list">
                                    <label>Street address <abbr class="required" title="required">*</abbr></label>
                                    <input type="text" name="address" class="form-control" placeholder="House number and street name" required>
                                    <div class="error-message" id="address-error"></div>
                                </div>

                                <div class="checkout-form-list">
                                    <div class="custom-control custom-checkbox mt-0">
                                        
                                        <label class="custom-control-label" for="save_address"><input type="checkbox" class="custom-control-input" name="saved_address" value="Yes" id="save_address" style="    width: 19px;
    height: 18px;    vertical-align: sub;    margin-right: 8px;"> Do you want to save your address?</label>
                                    </div>
                                </div>

                                <div id="collapseFive" class="collapse">
                                    <div class="checkout-form-list checkout-form-list-custom-control">
                                        <div class="custom-control custom-radio d-flex">
                                            <input type="radio" class="custom-control-input" id="address_type1" name="address_type" value="1" checked>
                                            <label class="custom-control-label" for="address_type1">Home Address</label>
                                        </div>
                                    </div>
                                    <div class="checkout-form-list checkout-form-list-custom-control">
                                        <div class="custom-control custom-radio d-flex">
                                            <input type="radio" class="custom-control-input" id="address_type2" name="address_type" value="2">
                                            <label class="custom-control-label" for="address_type2">Office Address</label>
                                        </div>
                                    </div>
                                    <div class="checkout-form-list checkout-form-list-custom-control">
                                        <div class="custom-control custom-radio d-flex">
                                            <input type="radio" class="custom-control-input" id="address_type3" name="address_type" value="3">
                                            <label class="custom-control-label" for="address_type3">Other Address</label>
                                        </div>
                                    </div>
                                </div>

                                <!-- Ship to different address -->
                                <div class="different-address">
                                    <div class="ship-different-title">
                                        <h3>
                                            <label>Ship to a different address?</label>
                                            <input type="checkbox" id="different-shipping" name="shipping-toggle">
                                        </h3>
                                    </div>
                                    <div id="shipping-address" style="display: none;">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="checkout-form-list">
                                                    <label>Name <abbr class="required" title="required">*</abbr></label>
                                                    <input type="text" name="shipping_name" class="form-control">
                                                    <div class="error-message" id="shipping_name-error"></div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="checkout-form-list">
                                                    <label>Email <abbr class="required" title="required">*</abbr></label>
                                                    <input type="email" name="shipping_email" class="form-control">
                                                    <div class="error-message" id="shipping_email-error"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="checkout-form-list">
                                                    <label>Phone <abbr class="required" title="required">*</abbr></label>
                                                    <input type="text" name="shipping_phone" class="form-control">
                                                    <div class="error-message" id="shipping_phone-error"></div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="checkout-form-list">
                                                    <label>Pin Code <abbr class="required" title="required">*</abbr></label>
                                                    <input type="text" name="shipping_pin_code" id="shipping_pinCode" class="form-control applypin">
                                                    <div class="error-message" id="shipping_pin_code-error"></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="checkout-form-list">
                                                    <label>City <abbr class="required" title="required">*</abbr></label>
                                                    <input type="text" name="shipping_city" class="form-control">
                                                    <div class="error-message" id="shipping_city-error"></div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="checkout-form-list">
                                                    <label>State <abbr class="required" title="required">*</abbr></label>
                                                    <input type="text" name="shipping_state" class="form-control">
                                                    <div class="error-message" id="shipping_state-error"></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="checkout-form-list">
                                            <label>Street address <abbr class="required" title="required">*</abbr></label>
                                            <input type="text" name="shipping_address" class="form-control" placeholder="House number and street name">
                                            <div class="error-message" id="shipping_-error"></div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <!-- Order Summary -->
                        <div class="col-lg-6 col-md-12 col-12">
                            <div class="your-order">
                                <h3>Your order</h3>
                                <div class="your-order-table table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="product-name">Product</th>
                                                <th class="product-total">Total</th>
                                            </tr>							
                                        </thead>
                                        <tbody class="cartSummary">
                                            <!-- Cart items rendered dynamically here -->
                                        </tbody>
                                     
                                    </table>
                                </div>

                                <!-- Payment Method -->
                                <div class="payment-methods" id="payment_method">
                                    <div class="ltn__checkout-payment-method mt-50">
                                        <h4 class="title-2">Payment Method</h4>
                                        <div id="checkout_accordion_1">
                                            <div class="card" style="padding: 13px;">
                                                <div class="custom-control custom-radio d-flex">
                                                    <input type="radio" class="custom-control-input" id="cod" name="payment_method" value="COD" checked  style="margin-right:10px">
                                                    <label class="custom-control-label" for="cod">COD</label>
                                                </div>
                                            </div>
                                            <div class="card" style="padding: 13px;">
                                                <div class="custom-control custom-radio d-flex mb-0">
                                                    <input type="radio" class="custom-control-input" id="online" name="payment_method" value="Online" style="margin-right:10px">
                                                    <label class="custom-control-label" for="online">Online</label>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="btn" type="submit">Place order</button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- checkout-area-end -->



        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>     
     <script>
document.addEventListener("DOMContentLoaded", function() {

    // Toggle shipping address visibility
    const shippingToggle = document.getElementById('different-shipping');
    const shippingDiv = document.getElementById('shipping-address');
    shippingToggle.addEventListener('change', function () {
        shippingDiv.style.display = this.checked ? 'block' : 'none';
    });

    // Checkout form validation
    const checkoutForm = document.querySelector(".checkout-form");

    checkoutForm.addEventListener("submit", function(event) {
        event.preventDefault(); // prevent default submission

        // Clear previous errors
        document.querySelectorAll(".error-message").forEach(el => el.textContent = '');
        document.querySelectorAll("input").forEach(input => input.classList.remove("error"));

        let isValid = true;

        const showError = (input, message) => {
            const errorElement = document.getElementById(`${input.name}-error`);
            if (errorElement) errorElement.textContent = message;
            input.classList.add("error");
            isValid = false;
        };

        // Billing details
        const billingFields = [
            {name: 'name', type: 'text'},
            {name: 'email', type: 'email'},
            {name: 'phone', type: 'phone'},
            {name: 'pin_code', type: 'text'},
            {name: 'city', type: 'text'},
            {name: 'state', type: 'text'},
            {name: 'address', type: 'text'}
        ];

        billingFields.forEach(field => {
            const input = checkoutForm.querySelector(`input[name="${field.name}"]`);
            if (!input.value.trim()) {
                showError(input, `${field.name.replace('_',' ')} is required.`);
            } else if (field.type === 'email' && !/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(input.value)) {
                showError(input, "Please enter a valid email address.");
            } else if (field.type === 'phone' && !/^\+?[0-9]{10,15}$/.test(input.value)) {
                showError(input, "Please enter a valid phone number.");
            }
        });

        // Shipping details if shipping is different
        if (shippingToggle.checked) {
            const shippingFields = [
                {name: 'shipping_name', type: 'text'},
                {name: 'shipping_email', type: 'email'},
                {name: 'shipping_phone', type: 'phone'},
                {name: 'shipping_pin_code', type: 'text'},
                {name: 'shipping_city', type: 'text'},
                {name: 'shipping_state', type: 'text'},
                {name: 'shipping_address', type: 'text'}
            ];

            shippingFields.forEach(field => {
                const input = checkoutForm.querySelector(`input[name="${field.name}"]`);
                if (!input.value.trim()) {
                    showError(input, `${field.name.replace('shipping_','').replace('_',' ')} is required.`);
                } else if (field.type === 'email' && !/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(input.value)) {
                    showError(input, "Please enter a valid email address.");
                } else if (field.type === 'phone' && !/^\+?[0-9]{10,15}$/.test(input.value)) {
                    showError(input, "Please enter a valid phone number.");
                }
            });
        }

        // If everything is valid, submit form
        if (isValid) {
            checkoutForm.submit();
        }
    });

});
</script>
