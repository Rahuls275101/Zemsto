   <?php
use App\Models\Commanmodel;

$commanmodel = new Commanmodel();

 
?>


                 <?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 44)); ?>
 
 <section class="page-title-area text-white bg_cover"
        style="background-image: url('<?php echo base_url('assets/images/'); ?>/<?php echo $about->cms_image; ?>');">
        <div class="container">
            <div class="page-title-inner text-center">
                <h1 class="page-title"><?php echo $about->cms_page_heading; ?></h1>
                <div class="gd-breadcrumb">
    <span class="breadcrumb-entry">
        <a href="<?php echo base_url(''); ?>">Home</a>
    </span>
    <span class="separator"></span>
    <span class="breadcrumb-entry active">
       <?php echo $about->cms_page_heading; ?>
    </span>
</div>
<p class="breadcrumb-description">
   <?php echo $about->cms_page_small_description; ?>
</p>
            </div>
        </div>
    </section>
<section class="luxury-section">
    <div class="luxury-wrapper">
        
        
         <?php $about46 = $commanmodel->get_single_query('cms_pages',array('cms_id' => 50)); ?>
  <?php $about47 = $commanmodel->get_single_query('cms_pages',array('cms_id' => 51)); ?>
   <?php $about48 = $commanmodel->get_single_query('cms_pages',array('cms_id' => 52)); ?>
    <?php $about49 = $commanmodel->get_single_query('cms_pages',array('cms_id' => 53)); ?>

 
        
        <div class="luxury-content">
            <span class="luxury-subtitle">
                <?php echo $about46->cms_page_heading; ?>
            </span>
            <h2>
                <?php echo $about46->cms_page_small_description; ?>
            </h2>
            <p>
               <?php echo $about46->cms_page_description; ?>
            </p>
            <div class="luxury-features">
                <div class="feature-box">
                    <h4><?php echo $about47->cms_page_heading; ?></h4>
                    <span> <?php echo $about47->cms_page_small_description; ?></span>
                </div>
                <div class="feature-box">
                    <h4><?php echo $about48->cms_page_heading; ?></h4>
                    <span> <?php echo $about48->cms_page_small_description; ?></span>
                </div>
                <div class="feature-box">
                    <h4><?php echo $about49->cms_page_heading; ?></h4>
                    <span> <?php echo $about49->cms_page_small_description; ?></span>
                </div>
            </div>
        </div>
        
        <div class="luxury-gallery">
            <?php if (!empty($gallery_images) && count($gallery_images) > 0): ?>
                <?php 
                    $largeImage = $gallery_images[0] ?? null;
                    $smallImages = array_slice($gallery_images, 1, 2);
                    $wideImage = $gallery_images[3] ?? null;
                ?>
                
                <?php if ($largeImage): ?>
                    <div class="gallery-item large">
                        <img src="<?= base_url($largeImage->image_path) ?>" alt="<?= esc($title ?? 'Luxury Property') ?>">
                    </div>
                <?php endif; ?>
                
                <?php foreach ($smallImages as $image): ?>
                    <div class="gallery-item small">
                        <img src="<?= base_url($image->image_path) ?>" alt="<?= esc($title ?? 'Luxury Property') ?>">
                    </div>
                <?php endforeach; ?>
                
                <?php if ($wideImage): ?>
                    <div class="gallery-item wide">
                        <img src="<?= base_url($wideImage->image_path) ?>" alt="<?= esc($title ?? 'Luxury Property') ?>">
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <!-- Default fallback -->
                <div class="gallery-item large">
                    <img src="<?= base_url('assets/images/landscape/newi1.webp') ?>" alt="Luxury Property">
                </div>
                <div class="gallery-item small">
                    <img src="<?= base_url('assets/images/landscape/2.webp') ?>" alt="Luxury Property">
                </div>
                <div class="gallery-item small">
                    <img src="<?= base_url('assets/images/landscape/3.webp') ?>" alt="Luxury Property">
                </div>
                <div class="gallery-item wide">
                    <img src="<?= base_url('assets/images/landscape/4.webp') ?>" alt="Luxury Property">
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

