   <?php
use App\Models\Commanmodel;

$commanmodel = new Commanmodel();

 
?>


                 <?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 40)); ?>
 
 <section class="page-title-area text-white bg_cover"
        style="background-image: url('<?php echo base_url('assets/images/'); ?>/<?php echo $about->cms_image; ?>');">
        <div class="container">
            <div class="page-title-inner text-center">
                <h1 class="page-title"><?php echo $about->cms_page_heading; ?></h1>
                <div class="gd-breadcrumb">
    <span class="breadcrumb-entry">
        <a href="<?php echo base_url(''); ?>">Home</a>
    </span>
    <span class="separator"></span>
    <span class="breadcrumb-entry active">
       <?php echo $about->cms_page_heading; ?>
    </span>
</div>
<p class="breadcrumb-description">
   <?php echo $about->cms_page_small_description; ?>
</p>
            </div>
        </div>
    </section>


<section class="heritage-fruit-section">
    <div class="heritage-grid">
        <?php if (!empty($collections) && count($collections) > 0): ?>
            <?php foreach ($collections as $collection): ?>
                <?php
                    // Set card class based on database values
                    $cardClass = 'heritage-card';
                    if ($collection->is_hero_card == 1) {
                        $cardClass .= ' hero-card';
                    }
                    if ($collection->is_wide_card == 1) {
                        $cardClass .= ' wide-card';
                    }
                    
                    // Get gallery images
                    $galleryImages = $collection->gallery_images ?? [];
                    $displayImages = [];
                    
                    if (!empty($galleryImages)) {
                        foreach ($galleryImages as $gallery) {
                            $displayImages[] = $gallery->image_path;
                        }
                    } elseif (!empty($collection->exotic_image)) {
                        // Determine folder based on category
                        $folder = '';
                        switch($collection->title) {
                            case 'Citrus Varieties':
                                $folder = 'citrus/';
                                break;
                            case 'Mango':
                                $folder = 'mango/';
                                break;
                            case 'Litchi':
                                $folder = 'litchi/';
                                break;
                            case 'Chickoo (Sapodilla)':
                                $folder = 'chicoo/';
                                break;
                            case 'Jamun':
                                $folder = 'jamun/';
                                break;
                            case 'Avocado':
                                $folder = 'avacado/';
                                break;
                            case 'Anjeer':
                                $folder = 'avacado/';
                                break;
                            default:
                                $folder = '';
                        }
                        $displayImages = ['assets/images/img/HERITAGEFRUITTREES/' . $folder . $collection->exotic_image];
                    }
                ?>
                
                <div class="<?= $cardClass ?>">
                    <div class="heritage-content">
                      
                            <h2><?= esc($collection->title) ?></h2>
                      
                        <p><?= $collection->description ?></p>
                    </div>
                    
                    <?php if (!empty($displayImages)): ?>
                        <div class="heritage-image <?= ($collection->is_wide_card == 1) ? 'image-grid' : '' ?>">
                            <?php foreach ($displayImages as $index => $imagePath): ?>
                                <?php if ($collection->is_wide_card == 1): ?>
                                    <?php if ($index < 2): ?>
                                        <img src="<?= base_url($imagePath) ?>" alt="<?= esc($collection->title) ?>">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if ($index < 1): ?>
                                        <img src="<?= base_url($imagePath) ?>" alt="<?= esc($collection->title) ?>">
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center" style="padding: 60px 0;">
                <p style="font-size: 18px; color: #636e72;">No heritage fruit collections available at the moment.</p>
            </div>
        <?php endif; ?>
    </div>
</section>
