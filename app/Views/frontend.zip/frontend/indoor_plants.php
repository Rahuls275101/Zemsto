   <?php
use App\Models\Commanmodel;

$commanmodel = new Commanmodel();

 
?>


                 <?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 41)); ?>
 
 <section class="page-title-area text-white bg_cover"
        style="background-image: url('<?php echo base_url('assets/images/'); ?>/<?php echo $about->cms_image; ?>');">
        <div class="container">
            <div class="page-title-inner text-center">
                <h1 class="page-title"><?php echo $about->cms_page_heading; ?></h1>
                <div class="gd-breadcrumb">
    <span class="breadcrumb-entry">
        <a href="<?php echo base_url(''); ?>">Home</a>
    </span>
    <span class="separator"></span>
    <span class="breadcrumb-entry active">
       <?php echo $about->cms_page_heading; ?>
    </span>
</div>
<p class="breadcrumb-description">
   <?php echo $about->cms_page_small_description; ?>
</p>
            </div>
        </div>
    </section>
<section class="premium-exotic-section">
    <div class="exotic-grid">
        <?php if (!empty($collections) && count($collections) > 0): ?>
            <?php 
                // Separate wide cards and single cards
                $wideCards = [];
                $singleCards = [];
                foreach ($collections as $collection) {
                    if ($collection->is_wide_card == 1) {
                        $wideCards[] = $collection;
                    } else {
                        $singleCards[] = $collection;
                    }
                }
            ?>
            
            <!-- Display Wide Cards -->
            <?php foreach ($wideCards as $collection): ?>
                <?php
                    $cardClass = 'exotic-card wide-card';
                    
                    // Get gallery images
                    $galleryImages = $collection->gallery_images ?? [];
                    $displayImages = [];
                    
                    if (!empty($galleryImages)) {
                        foreach ($galleryImages as $gallery) {
                            $displayImages[] = $gallery->image_path;
                        }
                    } elseif (!empty($collection->exotic_image)) {
                        $displayImages = ['assets/images/indoor/' . $collection->exotic_image];
                    }
                ?>
                
                <div class="<?= $cardClass ?>">
                    <div class="exotic-content">
                       
                            <h2><?= esc($collection->title) ?></h2>
                       
                        <p><?= $collection->description ?></p>
                    </div>
                    
                    <?php if (!empty($displayImages)): ?>
                        <div class="two-layout">
                            <?php foreach ($displayImages as $index => $imagePath): ?>
                                <?php if ($index < 2): ?>
                                    <img src="<?= base_url($imagePath) ?>" alt="<?= esc($collection->title) ?>">
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
            
            <!-- Display Single Cards -->
            <?php if (!empty($singleCards)): ?>
                <div class="remaining-cards">
                    <?php foreach ($singleCards as $collection): ?>
                        <?php
                            // Get gallery images
                            $galleryImages = $collection->gallery_images ?? [];
                            $displayImages = [];
                            
                            if (!empty($galleryImages)) {
                                foreach ($galleryImages as $gallery) {
                                    $displayImages[] = $gallery->image_path;
                                }
                            } elseif (!empty($collection->exotic_image)) {
                                $displayImages = ['assets/images/indoor/' . $collection->exotic_image];
                            }
                        ?>
                        
                        <div class="landscape-card">
                            <div class="landscape-content">
                              
                                    <h2><?= esc($collection->title) ?></h2>
                                
                                <p><?= esc($collection->description) ?></p>
                            </div>
                            <?php if (!empty($displayImages)): ?>
                                <div class="landscape-image">
                                    <?php foreach ($displayImages as $index => $imagePath): ?>
                                        <?php if ($index < 1): ?>
                                            <img src="<?= base_url($imagePath) ?>" alt="<?= esc($collection->title) ?>">
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div class="col-12 text-center" style="padding: 60px 0;">
                <p style="font-size: 18px; color: #636e72;">No indoor greenery collections available at the moment.</p>
            </div>
        <?php endif; ?>
    </div>
</section>