<?php 

use App\Models\Commanmodel;
 $commanmodel = new Commanmodel();
 
    $request = service('request');

?>
 
                 <?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 5)); ?>
 <div class="breadcrumbs-area mb-50">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="breadcrumbs-menu">
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#" class="active">  <?php echo $about->cms_page_heading; ?></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- breadcrumbs-area-end --> 
<!-- about-main-area-start -->
<div class="about-main-area mb-70">
  <div class="container">
    <div class="row">
   
      <div class="col-lg-12 col-md-12 col-12">
        <div class="about-content">
          <h3>The Journey of <span>Ajit Kumar Panicker</span></h3>
           <?php echo $about->cms_page_description; ?>


</div>
</div></div></div></div>

