   <?php
use App\Models\Commanmodel;

$commanmodel = new Commanmodel();

 
?>


                 <?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 43)); ?>
 
 <section class="page-title-area text-white bg_cover"
        style="background-image: url('<?php echo base_url('assets/images/'); ?>/<?php echo $about->cms_image; ?>');">
        <div class="container">
            <div class="page-title-inner text-center">
                <h1 class="page-title"><?php echo $about->cms_page_heading; ?></h1>
                <div class="gd-breadcrumb">
    <span class="breadcrumb-entry">
        <a href="<?php echo base_url(''); ?>">Home</a>
    </span>
    <span class="separator"></span>
    <span class="breadcrumb-entry active">
       <?php echo $about->cms_page_heading; ?>
    </span>
</div>
<p class="breadcrumb-description">
   <?php echo $about->cms_page_small_description; ?>
</p>
            </div>
        </div>
    </section>

<section class="garden-gallery-section">
    <div class="container">
        <div class="gallery-wrapper">
            <?php if (!empty($gallery_images) && count($gallery_images) > 0): ?>
                <!-- Left Big Image (First image) -->
                <div class="gallery-main-item">
                    <img src="<?= base_url($gallery_images[0]->image_path) ?>" alt="<?= esc($title ?? 'Exclusive Landscape') ?>">
                    <div class="gallery-overlay">
                        <h3><?= $title ?? 'Exclusive Landscape Creation' ?></h3>
                    </div>
                </div>

                <!-- Right Side Images (Remaining images) -->
                <div class="gallery-grid">
                    <?php foreach ($gallery_images as $index => $image): ?>
                        <?php if ($index > 0): // Skip first image ?>
                            <div class="gallery-item">
                                <img src="<?= base_url($image->image_path) ?>" alt="<?= esc($title ?? 'Gallery Image') ?>">
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <!-- Default fallback -->
                <div class="gallery-main-item">
                    <img src="<?= base_url('assets/images/new11.webp') ?>" alt="Exclusive Landscape Creation">
                    <div class="gallery-overlay">
                        <h3>Exclusive Landscape Creation</h3>
                    </div>
                </div>
                <div class="gallery-grid">
                    <div class="gallery-item">
                        <img src="<?= base_url('assets/images/22.webp') ?>" alt="Gallery Image">
                    </div>
                    <div class="gallery-item">
                        <img src="<?= base_url('assets/images/33.webp') ?>" alt="Gallery Image">
                    </div>
                    <div class="gallery-item">
                        <img src="<?= base_url('assets/images/1.webp') ?>" alt="Gallery Image">
                    </div>
                    <div class="gallery-item">
                        <img src="<?= base_url('assets/images/new2.webp') ?>" alt="Gallery Image">
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>