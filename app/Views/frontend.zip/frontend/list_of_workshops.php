<section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="https://snindustries.org/clinicianleader/assets/frontend/assets/img/figure/figure2.jpg">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="breadcrumbs-area">
            <h1>List of Workshops</h1>
            <ul>
              <li> <a href="https://snindustries.org/clinicianleader">Home</a> </li>
              <li>List of Workshops</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Inne Page Banner Area End Here --> 
  <!-- About Us Start Here -->
  <section class="about-wrap-layout5" style="padding:5rem 0 4rem">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="about-box-layout13">
			<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="about-box-layout13">
<h3>List of Workshops</h3>


<ul style="margin-bottom:15px">
<li>Sydney 23-24 November<a href="https://buy.stripe.com/14A9AT7Xc4pEcVWarDcjS00" target="_blank">click here for registration </a></li>
<li>Melbourne 2-3 December <a href="https://buy.stripe.com/cNi3cv7XcaO2f44fLXcjS01" target="_blank">click here for registration</a></li>
<li>Brisbane 30 November -1 December <a href="https://buy.stripe.com/4gMbJ1gtI3lA9JKczLcjS02" target="_blank">click here for registration</a></li>
<li>Canberra 25-26 November <a href="https://buy.stripe.com/3cI00j91g8FU4pq6bncjS04" target="_blank">click here for registration</a></li>
<li>Adelaide 16-17 December <a href="https://buy.stripe.com/3cI14n3GWbS6aNO1V7cjS03" target="_blank">click here for registration</a></li>
<li>Perth 14-15 December <a href="https://buy.stripe.com/7sY9ATelAg8mcVW2ZbcjS05" target="_blank">click here for registration</a></li>
<li>Hobart 7-8 December <a href="https://buy.stripe.com/aFafZhdhwg8m4pq1V7cjS06" target="_blank">click here for registration</a></li>
</ul>


</div>
</div>
</div>
</div>
          </div>
        </div>
        
      </div>
    </div>
  </section>
