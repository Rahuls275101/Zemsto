   <?php
use App\Models\Commanmodel;

$commanmodel = new Commanmodel();

 
?>


                 <?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 45)); ?>
 
 <section class="page-title-area text-white bg_cover"
        style="background-image: url('<?php echo base_url('assets/images/'); ?>/<?php echo $about->cms_image; ?>');">
        <div class="container">
            <div class="page-title-inner text-center">
                <h1 class="page-title"><?php echo $about->cms_page_heading; ?></h1>
                <div class="gd-breadcrumb">
    <span class="breadcrumb-entry">
        <a href="<?php echo base_url(''); ?>">Home</a>
    </span>
    <span class="separator"></span>
    <span class="breadcrumb-entry active">
       <?php echo $about->cms_page_heading; ?>
    </span>
</div>
<p class="breadcrumb-description">
   <?php echo $about->cms_page_small_description; ?>
</p>
            </div>
        </div>
    </section>

<section class="maintenance-section">
    <div class="maintenance-container">
        <!-- Images -->
        <div class="maintenance-gallery">
            <?php if (!empty($gallery_images) && count($gallery_images) > 0): ?>
                <?php 
                    $mainImage = $gallery_images[0] ?? null;
                    $sideImages = array_slice($gallery_images, 1, 2);
                ?>
                
                <?php if ($mainImage): ?>
                    <div class="main-image">
                        <img src="<?= base_url($mainImage->image_path) ?>" alt="<?= esc($title ?? 'Maintenance Services') ?>">
                    </div>
                <?php endif; ?>
                
                <div class="side-images">
                    <?php foreach ($sideImages as $image): ?>
                        <img src="<?= base_url($image->image_path) ?>" alt="<?= esc($title ?? 'Maintenance Services') ?>">
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <!-- Default fallback -->
                <div class="main-image">
                    <img src="<?= base_url('assets/images/maintenance/11.webp') ?>" alt="Maintenance Services">
                </div>
                <div class="side-images">
                    <img src="<?= base_url('assets/images/maintenance/22.webp') ?>" alt="Maintenance Services">
                    <img src="<?= base_url('assets/images/maintenance/33.webp') ?>" alt="Maintenance Services">
                </div>
            <?php endif; ?>
        </div>


 <?php $about46 = $commanmodel->get_single_query('cms_pages',array('cms_id' => 46)); ?>
  <?php $about47 = $commanmodel->get_single_query('cms_pages',array('cms_id' => 47)); ?>
   <?php $about48 = $commanmodel->get_single_query('cms_pages',array('cms_id' => 48)); ?>
    <?php $about49 = $commanmodel->get_single_query('cms_pages',array('cms_id' => 49)); ?>

        <!-- Content -->
        <div class="maintenance-content">
            <span class="maintenance-subtitle">
              <?php echo $about46->cms_page_heading; ?>
            </span>
            <h2>
                 <?php echo $about46->cms_page_small_description; ?>
            </h2>
            <p>
                  <?php echo $about46->cms_page_description; ?>
            </p>
            <div class="maintenance-services">
                <div class="service-card">
                    <h4><?php echo $about47->cms_page_heading; ?></h4>
                    <span>
                         <?php echo $about47->cms_page_small_description; ?>
                    </span>
                </div>
                <div class="service-card">
                    <h4><?php echo $about48->cms_page_heading; ?></h4>
                    <span>
                          <?php echo $about48->cms_page_small_description; ?>
                    </span>
                </div>
                <div class="service-card">
                    <h4><?php echo $about49->cms_page_heading; ?></h4>
                    <span>
                         <?php echo $about49->cms_page_small_description; ?>
                    </span>
                </div>
            </div>
        </div>
    </div>
</section>
