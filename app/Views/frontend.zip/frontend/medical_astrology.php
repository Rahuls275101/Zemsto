
<?php
use App\Models\Commanmodel;

$commanmodel = new Commanmodel();
?>

<main>
  <section class="pt-45 pb-45 bg-brand-4">
    <div class="container">
      <div class="archive-header">
        <div class="row">
        <div class="col-md-8">
        <div class="archive-header-title">
            
            <?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 15)); ?>
          <h2 class="font-heading mb-0"> <?php echo $about->cms_page_heading; ?> </h2>
          <p class="mb-0"> <?php echo $about->cms_page_small_description; ?></p>
        </div></div>
        <div class="col-md-4" style="text-align: right;"><div class="breadcrumb"> <a href="<?php echo base_url(''); ?>" rel="nofollow">Home</a> <span></span> Medical Astrology </div></div>
      </div>
      </div>
    </div>
  </section>
<section class="featured-slider-1 pt-15 pb-45">
    <div class="position-relative">
      <div class="container inners">
        <div class="">
          <div class="">
            <div class="row ">
              
              <div class="col-lg-12 mt-30">
 <?php echo $about->cms_page_description; ?>

              </div> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>