

<?php
use App\Models\Commanmodel;

$commanmodel = new Commanmodel();

  $team= $commanmodel->all_multiple_query_order_by('team',array(),'team_id','ASC');
?>

    <?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 24)); ?>
  <style> .action-items-primary-btn
 {
    font-size: 14px;
    display: inline-block;
    padding: 14px 24px;
    color: #ffffff;
    background: linear-gradient(to right, rgba(0, 130, 159, 1) 0%, rgba(1, 95, 194, 1) 100%);
    font-weight: 500;
    border: 1px solid;
    border-color: #0049a3;
    cursor: pointer;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    -ms-border-radius: 4px;
    -o-border-radius: 4px;
    border-radius: 4px;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
    transition: all 0.3s ease-out;
}</style><section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="<?php echo base_url('assets/frontend/'); ?>/assets/img/figure/figure2.jpg">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="breadcrumbs-area">
            <h1><?php echo $about->cms_page_heading; ?></h1>
            <ul>
              <li> <a href="<?php echo base_url(''); ?>">Home</a> </li>
              <li><?php echo $about->cms_page_heading; ?></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Inne Page Banner Area End Here --> 
  <!-- About Us Start Here -->
  <section class="about-wrap-layout5">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="about-box-layout13">
<?php echo $about->cms_page_description; ?>
<a href="<?php echo base_url(''); ?>/list-of-workshops" class="action-items-primary-btn">Register here for Workshops</a>
          </div>
        </div>

      </div>
    </div>
  </section>
   <section class="testmonial-wrap-layout2 bg-common" data-bg-image="<?php echo base_url('assets/frontend/'); ?>/assets/img/testimonial/testimonial-bg1.jpg">
    <div class="container">
      <div class="rc-carousel dot-control-layout2" data-loop="true" data-items="1" data-margin="30" data-autoplay="true" data-autoplay-timeout="5000"
                    data-smart-speed="2000" data-dots="true" data-nav="false" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="false"
                    data-r-x-small-dots="true" data-r-x-medium="1" data-r-x-medium-nav="false" data-r-x-medium-dots="true" data-r-small="1"
                    data-r-small-nav="false" data-r-small-dots="true" data-r-medium="1" data-r-medium-nav="false" data-r-medium-dots="true"
                    data-r-large="1" data-r-large-nav="false" data-r-large-dots="true" data-r-extra-large="1" data-r-extra-large-nav="false"
                    data-r-extra-large-dots="true">
  <?php foreach($team as $teamrow) { ?>
        <div class="testmonial-box-layout1">
          <div class="item-img"> <img src="<?php echo base_url('assets/team/'); ?>/<?php echo $teamrow->team_logo; ?>" class="img-fulid rounded-circle" alt="Robert Addison"> </div>
          <div class="item-content">
           <?php echo $teamrow->overview; ?>
            <h3 class="item-title"><?php echo $teamrow->team_name; ?></h3>
            <h4 class="sub-title"><?php echo $teamrow->designation; ?></h4>
          </div>
        </div>
        <?php } ?>
    

      </div>
    </div>
  </section>