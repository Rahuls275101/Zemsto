<style>.post-comments-list img{ height:42px; width:42px}</style>
<section class="blog-detail-wrap bg-light-primary100" style="padding: 150px 0px 60px">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-9 col-lg-8 col-12">
                <!-- Facebook Style Post Creator -->
                <?php if(session()->get('loggedin')): ?>
                <div class="mainDiv" id="postCreator">
                    <div class="title">
                        <a href="#" id="createPostBtn">
                            <i class="fa fa-pencil" aria-hidden="true"></i> Create a Post
                        </a>
                       
                        <p><i class="fa fa-times" aria-hidden="true" id="closePostCreator"></i></p>
                    </div>
                    
                    <div id="body">
                        <div class="imtcontainer">
                            <div class="img">
                                <img id="userProfileImg" 
                                     src="<?= session()->get('loggedin')['user_photo'] ?? 'assets/images/default-avatar.jpg' ?>" 
                                     alt="<?= session()->get('loggedin')['user_name'] ?? 'User' ?>">
                            </div>
                            <div class="textarea">
                                <textarea id="postContent" onkeyup="InputAdjust(this)" 
                                          placeholder="What's on your mind, <?= session()->get('loggedin')['user_name'] ?? 'User' ?>?"></textarea>
                            </div>
                        </div>
                        
                        <div class="line">
                            <div class="colors">
                                <span onclick="setPostBackground('#e8eaee')"></span>
                                <span onclick="setPostBackground('#fcd85d')"></span>
                                <span onclick="setPostBackground('#f25467')"></span>
                                <span onclick="setPostBackground('#10aaff')"></span>
                                <span onclick="setPostBackground('#488ee8')"></span>
                                <span onclick="setPostBackground('#5a3be2')"></span>
                                <span onclick="setPostBackground('#5e6574')"></span>
                            </div>
                            <a href="#" id="showFeelingBtn"><i class="fa fa-smile-o" aria-hidden="true"></i></a>
                        </div>
                        
                        <div class="icons">
                            <div class="photos">
                                <a href="#" id="addMediaBtn">
                                    <i class="fa fa-picture-o" aria-hidden="true"></i> Photo/Video
                                </a>
                            </div>
                
                            <div class="back" style="display: none;">
                                <a href="#" id="changeBackgroundBtn">
                                    <i style="color: #f7923c" class="fa fa-fonticons" aria-hidden="true"></i> Background Color
                                </a>
                            </div>
                            
                            <div class="footer">
                                <button id="submitPost" class="post-btn">Post</button>
                            </div>
                        </div>
                        
                        <!-- Hidden Inputs -->
                        <input type="file" id="mediaUpload" accept="image/*,video/*" style="display: none;">
                        <input type="hidden" id="postBackground" value="#ffffff">
                        <input type="hidden" id="postFeeling">
                        <input type="hidden" id="postLocation">
                        <input type="hidden" id="taggedUsers">
                    </div>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    <a href="<?= site_url('login') ?>">Login</a> to create posts and comments.
                </div>
                <?php endif; ?>
                
                <!-- Posts Container -->
                <div id="postsContainer"></div>
                
                <!-- Blog Content -->
                <div class="blog-detail-box">
                    <!-- Your existing blog content -->
                    
                    <!-- Comments Section for Blog Post -->
                  <!--  <div class="blog-comment">
                        <h3>Comments (<span id="blogCommentCount">0</span>)</h3>
                        <ul id="blogCommentsList">
                         ->
                        </ul>
                    </div>-->
                    
                    <?php if(session()->get('loggedin')): ?>
                  <!--  <div class="blog-form-box">
                        <form id="blogCommentForm">
                            <div class="row gutters-10">
                                <div class="col-12 form-group">
                                    <textarea id="blogCommentText" placeholder="Write a comment..." 
                                              class="textarea form-control" rows="3" required></textarea>
                                </div>
                                <div class="col-12 form-group margin-b-none">
                                    <button type="submit" class="item-btn" style="margin-top: 0px">
                                        Submit Comment
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" id="blogCommentPostId" value="1"> 
                            <input type="hidden" id="blogParentCommentId" value="0">
                        </form>
                    </div>-->
                    <?php else: ?>
                    <div class="alert alert-info">
                        <a href="<?= site_url('login') ?>">Login</a> to add comments.
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Reaction Modal -->
<div class="modal fade" id="reactionModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center">
                <div class="reaction-options">
                    <button class="reaction-option" data-type="like" title="Like">👍 </button>
                    <button class="reaction-option" data-type="love" title="Love">❤️ </button>
                    <button class="reaction-option" data-type="haha" title="Haha">😂 </button>
                    <button class="reaction-option" data-type="wow" title="Wow">😮 </button>
                    <button class="reaction-option" data-type="sad" title="Sad">😢 </button>
                    <button class="reaction-option" data-type="angry" title="Angry">😠 </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Post Comments Modal -->
<div class="modal fade" id="postCommentsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Comments</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="postCommentsContainer"></div>
                <?php if(session()->get('loggedin')): ?>
                <div class="mt-3">
                    <form id="postCommentForm">
                        <div class="input-group">
                            <textarea id="postCommentText" class="form-control" placeholder="Write a comment..." rows="2"></textarea>
                            <button type="submit" class="btn btn-primary">Post</button>
                        </div>
                        <input type="hidden" id="currentPostId" value="">
                        <input type="hidden" id="currentParentCommentId" value="0">
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Global variables
let currentPostId = null;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    loadPosts();
    loadBlogComments();
    setupEventListeners();
});

function setupEventListeners() {
    // Post Creator Toggle
    const createPostBtn = document.getElementById('createPostBtn');
    const closePostCreator = document.getElementById('closePostCreator');

    if (createPostBtn) {
        createPostBtn.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('postCreator').style.display = 'block';
        });
    }

    if (closePostCreator) {
        closePostCreator.addEventListener('click', function() {
            document.getElementById('postCreator').style.display = 'none';
        });
    }

    // Submit Post
    const submitPostBtn = document.getElementById('submitPost');
    if (submitPostBtn) {
        submitPostBtn.addEventListener('click', createPost);
    }

    // Media upload
    const addMediaBtn = document.getElementById('addMediaBtn');
    if (addMediaBtn) {
        addMediaBtn.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('mediaUpload').click();
        });
    }

    // Feeling
    const showFeelingBtn = document.getElementById('showFeelingBtn');
    if (showFeelingBtn) {
        showFeelingBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const feeling = prompt('How are you feeling? (e.g., Happy, Sad, Excited)');
            if (feeling) document.getElementById('postFeeling').value = feeling;
        });
    }

    // Blog comment form
    const blogCommentForm = document.getElementById('blogCommentForm');
    if (blogCommentForm) {
        blogCommentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitBlogComment();
        });
    }

    // Reaction modal buttons
    const reactionModal = document.getElementById('reactionModal');
    if (reactionModal) {
        reactionModal.addEventListener('shown.bs.modal', function() {
            setupReactionButtons();
        });
    }
}

// Load posts
function loadPosts() {
    fetch('<?= site_url("posts/getPosts/1") ?>')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const container = document.getElementById('postsContainer');
                container.innerHTML = '';

                if (!data.posts || data.posts.length === 0) {
                    container.innerHTML = '<div class="alert alert-info">No posts yet. Be the first to post!</div>';
                    return;
                }

                data.posts.forEach(post => {
                    container.innerHTML += createPostHtml(post);
                });

                // attach inline comment handlers (event delegation)
                attachPostEventListeners();
            }
        })
        .catch(error => console.error('Error loading posts:', error));
}

// Create post HTML (INLINE COMMENTS AREA + INLINE FORM ADDED)
function createPostHtml(post) {
    const profileImage = post.profile_image
        ? '<?= base_url() ?>' + post.profile_image
        : '<?= base_url("assets/images/default-avatar.jpg") ?>';

    let mediaHtml = '';
    if (post.media_url) {
        if (post.media_type === 'image') {
            mediaHtml = `<img src="<?= base_url('public') ?>/${post.media_url}" class="post-media img-fluid rounded mb-2" alt="Post image">`;
        } else if (post.media_type === 'video') {
            mediaHtml = `<video src="<?= base_url('public') ?>/${post.media_url}" controls class="post-media w-100 rounded mb-2"></video>`;
        }
    }

    const feelingHtml = post.feeling
        ? `<p class="text-muted mb-1"><i class="fas fa-smile"></i> Feeling ${escapeHtml(post.feeling)}</p>`
        : '';

    const locationHtml = post.location
        ? `<p class="text-muted mb-1"><i class="fas fa-map-marker-alt"></i> ${escapeHtml(post.location)}</p>`
        : '';

    // Reaction summary
    let reactionSummaryHtml = '';
    if (post.reactions && post.reactions.length > 0) {
        const reactionEmojis = {
            'like': '👍', 'love': '❤️', 'haha': '😂',
            'wow': '😮', 'sad': '😢', 'angry': '😠'
        };

        const uniqueReactions = [...new Set(post.reactions.map(r => r.type))];
        let summaryText = '';
        uniqueReactions.slice(0, 2).forEach(type => {
            summaryText += reactionEmojis[type] || '👍';
        });

        reactionSummaryHtml = `
            <div class="d-flex align-items-center mb-2">
                <span class="me-2">${summaryText}</span>
                <span class="text-muted">${post.reactions.length}</span>
            </div>
        `;
    }

    const userReaction = post.user_has_reacted ? post.user_has_reacted.type : null;
    const reactionBtnText = userReaction
        ? getReactionEmoji(userReaction) + ' ' + userReaction.charAt(0).toUpperCase() + userReaction.slice(1)
        : '👍 Like';

    return `
        <div class="card mb-3 post-item" data-post-id="${post.id}">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <img src="${profileImage}" alt="${escapeHtml(post.username)}" class="rounded-circle me-3" width="45" height="45">
                    <div class="flex-grow-1">
                        <h6 class="mb-0">${escapeHtml(post.username)}</h6>
                        <small class="text-muted">${post.formatted_date}</small>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-ellipsis-h"></i>
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" onclick="deletePost(${post.id}); return false;">Delete Post</a></li>
                        </ul>
                    </div>
                </div>

                <div class="post-content mb-3 p-3 rounded" style="background-color: ${post.background_color || '#ffffff'}">
                    <p class="mb-2">${escapeHtml(post.content)}</p>
                    ${mediaHtml}
                    ${feelingHtml}
                    ${locationHtml}
                </div>

                ${reactionSummaryHtml}

                <div class="d-flex border-top border-bottom py-2">
                    <button class="btn btn-link text-decoration-none flex-fill text-center reaction-btn ${userReaction ? 'text-primary' : 'text-muted'}"
                            onclick="showReactions(${post.id}); return false;">
                        <i class="fas fa-thumbs-up me-1"></i> ${reactionBtnText}
                    </button>

                    <!-- IMPORTANT: Comment button now toggles inline area -->
                    <button class="btn btn-link text-decoration-none flex-fill text-center"
                            onclick="toggleInlineComments(${post.id}); return false;">
                        <i class="fas fa-comment me-1"></i> Comment (${post.comment_count || 0})
                    </button>

                    <button class="btn btn-link text-decoration-none flex-fill text-center"
                            onclick="sharePost(${post.id}); return false;">
                        <i class="fas fa-share me-1"></i> Share
                    </button>
                </div>

                <!-- INLINE COMMENTS CONTAINER -->
                <div id="postComments-${post.id}" class="mt-3" style="display:none;">
                    <div class="post-comments-list" id="postCommentsList-${post.id}">
                        <p class="text-muted">Loading comments...</p>
                    </div>

                    <?php if(session()->get('loggedin')): ?>
                    <!-- INLINE COMMENT FORM (per post) -->
                    <form class="mt-2 inline-comment-form" data-post-id="${post.id}">
                        <div class="input-group">
                            <textarea class="form-control inlineCommentText" rows="2" placeholder="Write a comment..."></textarea>
                            <button type="submit" class="btn btn-primary">Post</button>
                        </div>
                        <input type="hidden" class="inlineParentId" value="0">
                        <small class="text-muted d-block mt-1 inlineReplyInfo" style="display:none;"></small>
                    </form>
                    <?php else: ?>
                    <div class="alert alert-info mt-2">
                        <a href="<?= site_url('login') ?>">Login</a> to add comments.
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    `;
}

/* =========================
   INLINE COMMENTS FUNCTIONS
========================= */

// Toggle inline comments under a post
function toggleInlineComments(postId) {
    const box = document.getElementById(`postComments-${postId}`);
    if (!box) return;

    const isHidden = (box.style.display === 'none' || box.style.display === '');
    box.style.display = isHidden ? 'block' : 'none';

    // Load comments only when opening
    if (isHidden) {
        loadInlineComments(postId);
    }
}

// Load comments for a post and render under it
function loadInlineComments(postId) {
    const listEl = document.getElementById(`postCommentsList-${postId}`);
    if (!listEl) return;

    listEl.innerHTML = `<p class="text-muted">Loading comments...</p>`;

    fetch(`<?= site_url("posts/getComments/") ?>${postId}`)
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                listEl.innerHTML = `<p class="text-danger">Failed to load comments.</p>`;
                return;
            }

            if (!data.comments || data.comments.length === 0) {
                listEl.innerHTML = `<p class="text-muted">No comments yet.</p>`;
                return;
            }

            listEl.innerHTML = data.comments.map(c => createInlineCommentHtml(c, postId)).join('');
        })
        .catch(() => {
            listEl.innerHTML = `<p class="text-danger">Error loading comments.</p>`;
        });
}

// Comment HTML (with replies + reply button)
function createInlineCommentHtml(comment, postId) {
    const profileImage = comment.profile_image
        ? '<?= base_url() ?>' + comment.profile_image
        : '<?= base_url("assets/images/default-avatar.jpg") ?>';

    let repliesHtml = '';
    if (comment.replies && comment.replies.length > 0) {
        repliesHtml = comment.replies.map(reply => `
            <div class="d-flex mt-2 ms-4">
                <img src="${reply.profile_image ? '<?= base_url() ?>' + reply.profile_image : '<?= base_url("assets/images/default-avatar.jpg") ?>'}"
                     alt="${escapeHtml(reply.username)}" class="rounded-circle me-2" width="30" height="30">
                <div class="flex-grow-1">
                    <div class="bg-light p-2 rounded">
                        <h6 class="mb-1" style="font-size: 13px;">
                            ${escapeHtml(reply.username)}
                            <small class="text-muted">${formatTimeAgo(reply.created_at)}</small>
                        </h6>
                        <p class="mb-0" style="font-size: 13px;">${escapeHtml(reply.content)}</p>
                    </div>
                </div>
            </div>
        `).join('');
    }

    return `
        <div class="d-flex mb-2">
            <img src="${profileImage}" alt="${escapeHtml(comment.username)}" class="rounded-circle me-2" width="36" height="36">
            <div class="flex-grow-1">
                <div class="bg-light p-2 rounded">
                    <h6 class="mb-1" style="font-size: 14px;">
                        ${escapeHtml(comment.username)}
                        <small class="text-muted">${formatTimeAgo(comment.created_at)}</small>
                    </h6>
                    <p class="mb-1" style="font-size: 14px;">${escapeHtml(comment.content)}</p>

                    <?php if(session()->get('loggedin')): ?>
                    <button class="btn btn-sm btn-link p-0 text-decoration-none"
                            onclick="setInlineReply(${postId}, ${comment.id}, '${escapeJs(comment.username)}'); return false;">
                        <small>Reply</small>
                    </button>
                    <?php endif; ?>
                </div>
                ${repliesHtml}
            </div>
        </div>
    `;
}

// When user clicks reply under a comment
function setInlineReply(postId, commentId, username) {
    const postBox = document.getElementById(`postComments-${postId}`);
    if (!postBox) return;

    const form = postBox.querySelector(`form.inline-comment-form[data-post-id="${postId}"]`);
    if (!form) return;

    form.querySelector('.inlineParentId').value = commentId;

    const info = form.querySelector('.inlineReplyInfo');
    info.style.display = 'block';
    info.textContent = `Replying to ${username} (click to cancel)`;
    info.onclick = function() {
        // cancel reply
        form.querySelector('.inlineParentId').value = '0';
        info.style.display = 'none';
        info.textContent = '';
        info.onclick = null;
        form.querySelector('.inlineCommentText').placeholder = 'Write a comment...';
    };

    const textarea = form.querySelector('.inlineCommentText');
    textarea.placeholder = `Reply to ${username}...`;
    textarea.focus();
}

// Attach listeners after posts are rendered
function attachPostEventListeners() {
    // handle all inline forms by delegation (so works for dynamic posts)
    document.querySelectorAll('form.inline-comment-form').forEach(form => {
        form.onsubmit = function(e) {
            e.preventDefault();

            const postId = this.getAttribute('data-post-id');
            const textarea = this.querySelector('.inlineCommentText');
            const parentId = this.querySelector('.inlineParentId').value;

            const content = textarea.value.trim();
            if (!content) {
                alert('Please write a comment');
                return;
            }

            const fd = new FormData();
            fd.append('post_id', postId);
            fd.append('parent_id', parentId);
            fd.append('content', content);

            fetch('<?= site_url("posts/addComment") ?>', {
                method: 'POST',
                body: fd,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    textarea.value = '';
                    this.querySelector('.inlineParentId').value = '0';

                    const info = this.querySelector('.inlineReplyInfo');
                    info.style.display = 'none';
                    info.textContent = '';
                    info.onclick = null;

                    textarea.placeholder = 'Write a comment...';

                    // reload inline comments for same post
                    loadInlineComments(postId);

                    // refresh posts counts (optional)
                    loadPosts();
                } else {
                    alert(data.message || 'Failed to add comment');
                }
            })
            .catch(() => alert('Error submitting comment'));
        };
    });
}

/* =========================
   REACTIONS (your existing)
========================= */
function showReactions(postId) {
    currentPostId = postId;
    const modal = new bootstrap.Modal(document.getElementById('reactionModal'));
    modal.show();
}

function setupReactionButtons() {
    document.querySelectorAll('.reaction-option').forEach(btn => {
        btn.onclick = function() {
            const type = this.getAttribute('data-type');
            addReaction(currentPostId, type);
            const modal = bootstrap.Modal.getInstance(document.getElementById('reactionModal'));
            modal.hide();
        };
    });
}

function addReaction(postId, type) {
    const formData = new FormData();
    formData.append('post_id', postId);
    formData.append('type', type);

    fetch('<?= site_url("posts/addReaction") ?>', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) loadPosts();
    });
}

/* =========================
   BLOG COMMENTS (unchanged)
========================= */
function loadBlogComments() {
    const postId = 1;
    fetch(`<?= site_url("posts/getPostComments/") ?>${postId}`)
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                const container = document.getElementById('blogCommentsList');
                const countElement = document.getElementById('blogCommentCount');

                countElement.textContent = data.total_comments || 0;
                container.innerHTML = '';

                if (!data.comments || data.comments.length === 0) {
                    container.innerHTML = '<li class="text-muted">No comments yet.</li>';
                } else {
                    data.comments.forEach(comment => {
                        container.innerHTML += createBlogCommentHtml(comment);
                    });
                }
            }
        });
}

function createBlogCommentHtml(comment) {
    const profileImage = comment.profile_image
        ? '<?= base_url() ?>' + comment.profile_image
        : '<?= base_url("assets/images/default-avatar.jpg") ?>';

    return `
        <li class="mb-3">
            <div class="d-flex">
                <img src="${profileImage}" alt="${escapeHtml(comment.username)}" class="rounded-circle me-3" width="40" height="40">
                <div class="flex-grow-1">
                    <div class="bg-light p-3 rounded">
                        <h6 class="mb-1">${escapeHtml(comment.username)} <small class="text-muted">${formatTimeAgo(comment.created_at)}</small></h6>
                        <p class="mb-0">${escapeHtml(comment.content)}</p>
                    </div>
                </div>
            </div>
        </li>
    `;
}

function submitBlogComment() {
    const content = document.getElementById('blogCommentText').value.trim();
    const postId = document.getElementById('blogCommentPostId').value;
    const parentId = document.getElementById('blogParentCommentId').value;

    if (!content) {
        alert('Please write a comment');
        return;
    }

    const formData = new FormData();
    formData.append('post_id', postId);
    formData.append('parent_id', parentId);
    formData.append('content', content);

    fetch('<?= site_url("posts/addComment") ?>', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            document.getElementById('blogCommentText').value = '';
            loadBlogComments();
        }
    });
}

/* =========================
   CREATE POST (your existing)
========================= */
function createPost() {
    const content = document.getElementById('postContent').value.trim();
    if (!content) {
        alert('Please write something to post');
        return;
    }

    const formData = new FormData();
    formData.append('content', content);
    formData.append('background_color', document.getElementById('postBackground').value);
    formData.append('feeling', document.getElementById('postFeeling').value);
    formData.append('location', document.getElementById('postLocation').value);

    const mediaFile = document.getElementById('mediaUpload').files[0];
    if (mediaFile) formData.append('media', mediaFile);

    fetch('<?= site_url("posts/create") ?>', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Post created successfully!');
            document.getElementById('postContent').value = '';
            document.getElementById('postCreator').style.display = 'none';
            loadPosts();
        } else {
            alert(data.message || 'Failed to create post');
        }
    })
    .catch(() => alert('Error creating post'));
}

/* =========================
   HELPERS
========================= */
function getReactionEmoji(type) {
    const emojis = {
        'like': '👍', 'love': '❤️', 'haha': '😂',
        'wow': '😮', 'sad': '😢', 'angry': '😠'
    };
    return emojis[type] || '👍';
}

function formatTimeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);

    if (diff < 60) return 'Just now';
    if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
    if (diff < 2592000) return Math.floor(diff / 604800) + 'w ago';
    if (diff < 31536000) return Math.floor(diff / 2592000) + 'mo ago';
    return Math.floor(diff / 31536000) + 'y ago';
}

function setPostBackground(color) {
    document.getElementById('postBackground').value = color;
    document.getElementById('postContent').style.backgroundColor = color;
}

function InputAdjust(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = (textarea.scrollHeight) + 'px';
}

function deletePost(postId) {
    if (!confirm('Are you sure you want to delete this post?')) return;

    fetch(`<?= site_url("posts/deletePost/") ?>${postId}`, {
        method: 'DELETE',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) loadPosts();
        else alert(data.message || 'Failed to delete post');
    });
}

// Optional
function sharePost(postId) {
    alert('Share feature not implemented yet (postId: ' + postId + ')');
}

// XSS safe helpers
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

// For putting username in onclick safely
function escapeJs(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}
</script>

<style>

.imtcontainer {
    display: flex;
    gap: 15px;
    margin-bottom: 20px;
}

.imtcontainer .img img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #1877f2;
}

.textarea textarea {
    width: 100%;
    border: none;
    resize: none;
    font-size: 16px;
    line-height: 1.5;
    min-height: 100px;
    padding: 15px;
    border-radius: 8px;
    background-color: #f0f2f5;
    transition: background-color 0.3s, border-color 0.3s;
    border: 2px solid transparent;
}

.textarea textarea:focus {
    outline: none;
    background-color: #ffffff;
    border-color: #1877f2;
}

.line {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0;
    border-top: 1px solid #e5e5e5;
    border-bottom: 1px solid #e5e5e5;
    margin-bottom: 15px;
}

.colors {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
}

.colors span {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    cursor: pointer;
    border: 2px solid white;
    box-shadow: 0 1px 3px rgba(0,0,0,0.2);
    transition: transform 0.2s;
}

.colors span:hover {
    transform: scale(1.2);
}


.footer .post-btn {
    background: #1877f2;
    color: white;
    border: none;
    padding: 10px 30px;
    border-radius: 6px;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.2s;
    width: 100%;
    font-size: 16px;
}

.footer .post-btn:hover {
    background: #166fe5;
}

/* Post Item Styles */
.post-item {
    background: white;
    border-radius: 10px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
    margin-bottom: 20px;
    padding: 20px;
    transition: transform 0.2s;
}

.post-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.post-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 15px;
    position: relative;
}

.post-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #1877f2;
}

.post-user-info {
    flex: 1;
}

.post-user-info h5 {
    margin: 0;
    font-size: 15px;
    font-weight: 600;
    color: #050505;
}

.post-time {
    color: #65676b;
    font-size: 13px;
}

.post-actions-dropdown {
    position: relative;
}

.dropdown-btn {
    background: none;
    border: none;
    font-size: 20px;
    color: #65676b;
    cursor: pointer;
    padding: 5px 10px;
    border-radius: 50%;
    transition: background-color 0.2s;
}

.dropdown-btn:hover {
    background-color: #f0f2f5;
}

.dropdown-content {
    display: none;
    position: absolute;
    right: 0;
    top: 100%;
    background: white;
    min-width: 150px;
    box-shadow: 0 8px 16px rgba(0,0,0,0.1);
    border-radius: 8px;
    z-index: 100;
}

.dropdown-content a {
    display: block;
    padding: 10px 15px;
    color: #050505;
    text-decoration: none;
    font-size: 14px;
    border-bottom: 1px solid #f0f2f5;
}

.dropdown-content a:hover {
    background-color: #f0f2f5;
}

.post-actions-dropdown:hover .dropdown-content {
    display: block;
}

.post-content {
    margin-bottom: 15px;
    padding: 15px;
    border-radius: 8px;
    border: 1px solid #e4e6eb;
}

.post-content p {
    margin: 0 0 10px 0;
    font-size: 15px;
    line-height: 1.5;
    color: #050505;
}

.post-media {
    max-width: 100%;
    border-radius: 8px;
    margin-top: 15px;
    max-height: 500px;
    object-fit: contain;
}

.post-feeling, .post-location {
    color: #65676b;
    font-size: 14px;
    margin: 10px 0 0 0;
    display: flex;
    align-items: center;
    gap: 5px;
}

.post-feeling i, .post-location i {
    font-size: 16px;
}

.reaction-summary {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 0;
    border-bottom: 1px solid #e4e6eb;
    margin-bottom: 10px;
}

.reaction-icons {
    font-size: 16px;
}

.reaction-count {
    color: #65676b;
    font-size: 14px;
}

.post-interactions {
    display: flex;
    gap: 5px;
    padding: 10px 0;
    border-bottom: 1px solid #e4e6eb;
}

.post-interactions button {
    flex: 1;
    background: none;
    border: none;
    padding: 8px;
    border-radius: 4px;
    cursor: pointer;
    color: #65676b;
    font-weight: 600;
    transition: background-color 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    font-size: 14px;
}

.post-interactions button:hover {
    background-color: #f0f2f5;
}

.post-interactions button.active {
    color: #1877f2;
}

.post-comments-section {
    padding-top: 15px;
}

/* Comment Styles */
.comment-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 5px;
}

.comment-header h4 {
    margin: 0;
    font-size: 14px;
    font-weight: 600;
}

.comment-time {
    color: #65676b;
    font-size: 12px;
}

.comment-content {
    margin: 5px 0 10px 0;
    font-size: 14px;
    line-height: 1.4;
    color: #050505;
}

.reply-item {
    display: flex;
    gap: 10px;
    margin-top: 10px;
    padding: 10px;
    background: #f0f2f5;
    border-radius: 8px;
    margin-left: 50px;
}

.reply-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    object-fit: cover;
}

.reply-content h5 {
    margin: 0;
    font-size: 13px;
    font-weight: 600;
}

.reply-content p {
    margin: 5px 0 0 0;
    font-size: 13px;
    color: #050505;
}

.reply-time {
    color: #65676b;
    font-size: 11px;
    margin-left: 5px;
}

/* Reaction Modal */
.reaction-options {
    display: flex;
    justify-content: space-around;
    padding: 20px;
    background: #f0f2f5;
    border-radius: 10px;
}

.reaction-options button {
    font-size: 30px;
    background: none;
    border: none;
    cursor: pointer;
    padding: 10px;
    border-radius: 50%;
    transition: transform 0.2s;
    background: white;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.reaction-options button:hover {
    transform: scale(1.2) translateY(-5px);
}

/* Responsive */
@media (max-width: 768px) {
    .icons > div {
        min-width: 100%;
    }
    
    .post-interactions {
        flex-direction: column;
    }
    
    .reaction-options {
        flex-wrap: wrap;
    }
    
    .reaction-options button {
        width: 40px;
        height: 40px;
        font-size: 24px;
        margin: 5px;
    }
    
    .reply-item {
        margin-left: 20px;
    }
}

@media (max-width: 480px) {
    .title {
        flex-direction: column;
        gap: 10px;
    }
    
    .title a {
        width: 100%;
        justify-content: center;
    }
    
    .colors {
        justify-content: center;
    }
    
    .imtcontainer {
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
    
    .post-header {
        flex-direction: column;
        text-align: center;
    }
    
    .post-user-info {
        text-align: center;
    }
}
</style>