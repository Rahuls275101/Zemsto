<?php 

use App\Models\Commanmodel;
 $commanmodel = new Commanmodel();
 
 $product_image = $commanmodel->all_multiple_query_order_by('product_image',array('product_image_product_id'=> $product->product_id),'product_image_id','ASC');
$related = $commanmodel->all_multiple_query_order_by_limit('product',array('product_status' => 'Active'),'product_id','DESC',5); 

$existingPlans  = $commanmodel->all_multiple_query_order_by(
    'product_pricing_plans',
    ['product_id' => $product->product_id],
    'id',
    'ASC'
);

?>
<style>tr:nth-child(even) {background-color: #f5f9fc;}</style>

  <section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="<?php echo base_url('assets/frontend/'); ?>/assets/img/figure/figure2.jpg">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="breadcrumbs-area">
            <h1><?php echo $product->product_name; ?></h1>
            <ul>
              <li> <a href="#">Home</a> </li>
              <li> <a href="#">Departments</a> </li>
              <li><?php echo $product->product_name; ?></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Inne Page Banner Area End Here --> 
  <!-- Single Department Start Here -->
  <section class="single-department-wrap-layout1 bg-light-primary100">
    <div class="container">
      <div class="row" id="no-equal-gallery">
        <div class="sidebar-widget-area sidebar-break-md col-xl-3 col-lg-4 col-12 no-equal-item">
          <div class="widget widget-department-info">
            <h3 class="section-title title-bar-primary">All Departments</h3>
            <ul class="nav nav-tabs tab-nav-list">
                    <?php $sn=1; foreach($related as $productrow) { ?>
              <li class="nav-item"> <a class=" <?= ($productrow->product_id == $product->product_id) ? 'active' : '' ?>" href="<?php echo base_url('/departments/') . '/' . $productrow->slug; ?>" ><?php echo $productrow->product_name; ?></a> </li>
               <?php $sn++; } ?>
            
            </ul>
          </div>
             <div class="widget widget-call-to-action-light">
            <div class="media"> <img src="<?php echo base_url('assets/frontend/'); ?>/assets/img/figure/figure6.png" alt="figure">
              <div class="media-body space-sm">
                <h4>Emergency Cases</h4>
                <span>2-800-700-6200</span> </div>
            </div>
          </div>
        </div>
        <div class="col-xl-9 col-lg-8 col-12 no-equal-item">
          <div class="tab-content">
            <div>
              <div class="single-departments-box-layout1">
                <div class="single-departments-img"> <img alt="single" src="<?php echo base_url('assets/images/'); ?>/<?php echo $product->product_thumbnail; ?>"> </div>
                <div class="item-content">
                  <div class="item-content-wrap">
                    <h3 class="item-title title-bar-primary5"><?php echo $product->product_name; ?></h3>
                    
                	<?php echo $product->product_description; ?>
                  </div>
                  <div class="row">
                    <div class="col-12">
                      <div class="item-cost">
                        <h3 class="item-title title-bar-primary7">Our Pricing Plan</h3>
                        
                        <table style="width:100%; border-collapse:collapse;">
                            <?php foreach($existingPlans as $plan): ?>
  <tr>
    <td style="padding:15px;"><strong><?= esc($plan->plan_name); ?></strong></td>
    <td style="padding:15px; text-align:center; font-weight:bold;">₹<?= $plan->offer_price ?: $plan->price; ?></td>
    <td style="padding:15px; text-align:right; font-weight:bold;">
        
        <a href="<?php echo base_url('buy-plan/'); ?>/<?= $plan->id; ?>" style="margin-left:10px; padding:5px 10px; background:#0d6efd; color:#fff; border:none; border-radius:4px; cursor:pointer;"   data-plan="<?= $plan->id; ?>"
            data-price="<?= $plan->offer_price ?: $plan->price; ?>">Buy Now</a>
    </td>
  </tr>
<?php endforeach; ?>

</table>





                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
   
      </div>
    </div>
  </section>






