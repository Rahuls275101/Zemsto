
  

<?php
use App\Models\Commanmodel;

$commanmodel = new Commanmodel();

  $team= $commanmodel->all_multiple_query_order_by('team',array(),'team_id','ASC');
?>
<?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 25)); ?>
  
  <section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="<?php echo base_url('assets/frontend/'); ?>/assets/img/figure/figure2.jpg">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="breadcrumbs-area">
            <h1><?php echo $about->cms_page_heading; ?></h1>
            <ul>
              <li> <a href="<?php echo base_url(''); ?>">Home</a> </li>
              <li><?php echo $about->cms_page_heading; ?></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Inne Page Banner Area End Here --> 
  <!-- About Us Start Here -->
  <section class="about-wrap-layout5">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="about-box-layout13">
			<?php echo $about->cms_page_description; ?>
          </div>
        </div>
        
      </div>
    </div>
  </section>

  