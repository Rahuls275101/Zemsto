<?php 

use App\Models\Commanmodel;
 $commanmodel = new Commanmodel();
 
 ?><section><img src="<?php echo base_url('assets/frontend/'); ?>/assets/img/store.jpg" style="width:100%"></section>
	<div class="breadcrumbs-area mb-50">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="breadcrumbs-menu">
						<ul>
							<li><a href="#">Home</a></li>
							<li><a href="#" class="active">shop</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- breadcrumbs-area-end -->
	<!-- shop-main-area-start -->
<div class="product-area pt-70 xs-mb">
  <div class="container">

    <div style="margin-bottom: 80px">
      <div class="col-lg-12">
        <h3 class="text-center">Fiction Books</h3>
        <!-- tab-menu-start -->
        <div class="tab-menu mb-40 text-center">
          <ul class="nav justify-content-center">
            <li><a class="active" href="#Mystery" data-bs-toggle="tab">Mystery </a></li>
            <li><a href="#Romance" data-bs-toggle="tab">Romance</a></li>
            <li><a href="#Suspense" data-bs-toggle="tab">Suspense</a></li>
            <li><a href="#Adventure" data-bs-toggle="tab">Adventure</a></li>
            <li><a href="#Supernatural" data-bs-toggle="tab">Supernatural</a></li>
            <li><a href="#Indian" data-bs-toggle="tab">Indian Legends</a></li>
          </ul>
        </div>
      </div>
      <div class="tab-content">
        <div class="tab-pane fade show active" id="Mystery">
          <div class="tab-active owl-carousel"> 
            <!-- single-product-start -->
            <?php $related = $commanmodel->all_multiple_query_order_by_limit_with_like('product',array('product_status' => 'Active'),array('product_category' => 3),'product_id','DESC',10);  
            
              foreach($related as $productfirstrow) {   $pro_variant = $commanmodel->all_multiple_query_order_by('pro_variant',array('variant_pro_id' => $productfirstrow->product_id),'pro_variant_id','ASC');
                    
                     $variant =  ($pro_variant)?$pro_variant[0]->varian:'';

                 $variant_yes =  ($pro_variant)?'Yes':'No';

                            ?>
            <div class="product-wrapper">
              <div class="product-img"> <a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"> 
              <img src="<?php echo base_url('assets/images/'); ?>/<?php echo $productfirstrow->product_thumbnail; ?>" alt="<?php echo $productfirstrow->product_name; ?>" class="primary" /> </a>
                <div class="quick-view"> <a class="action-view" href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" data-bs-target="#productModal" data-bs-toggle="modal" title="Quick View"> <i class="fa fa-search-plus"></i> </a> </div>
            
              </div>
              <div class="product-details text-center">
                <h4><a href="#"><?php echo $productfirstrow->product_name; ?></a></h4>
                <div class="product-price">
                  <ul>
                    <li>₹ <?php echo $productfirstrow->product_price; ?></li>
                  </ul>
                </div>
              </div>
              <div class="product-link">
                <div class="product-button"> <a href="#" title="Add to cart" class="AddToCart" data-product-id="<?php echo $productfirstrow->product_id; ?>" data-variant ="<?php echo $variant; ?>" data-qty="<?php echo $productfirstrow->quantity; ?>" data-variant-yes="<?php echo $variant_yes; ?>"><i class="fa fa-shopping-cart"></i>Add to cart</a> </div>
                <div class="add-to-link">
                  <ul>
                    <li><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" title="Details"><i class="fa fa-external-link"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php } ?>
            <!-- single-product-end --> 




          </div>
        </div>
        <div class="tab-pane fade" id="Romance">
          <div class="tab-active owl-carousel"> 
     <?php 
     $related = $commanmodel->all_multiple_query_order_by_limit_with_like('product',array('product_status' => 'Active'),array('product_category' => 7),'product_id','DESC',10);  
            
              foreach($related as $productfirstrow) {   $pro_variant = $commanmodel->all_multiple_query_order_by('pro_variant',array('variant_pro_id' => $productfirstrow->product_id),'pro_variant_id','ASC');
                    
                     $variant =  ($pro_variant)?$pro_variant[0]->varian:'';

                 $variant_yes =  ($pro_variant)?'Yes':'No';

                            ?>
            <div class="product-wrapper">
              <div class="product-img"> <a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"> 
              <img src="<?php echo base_url('assets/images/'); ?>/<?php echo $productfirstrow->product_thumbnail; ?>" alt="<?php echo $productfirstrow->product_name; ?>" class="primary" /> </a>
                <div class="quick-view"> <a class="action-view" href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" data-bs-target="#productModal" data-bs-toggle="modal" title="Quick View"> <i class="fa fa-search-plus"></i> </a> </div>
              
              </div>
              <div class="product-details text-center">
                <h4><a href="#"><?php echo $productfirstrow->product_name; ?></a></h4>
                <div class="product-price">
                  <ul>
                    <li>₹ <?php echo $productfirstrow->product_price; ?></li>
                  </ul>
                </div>
              </div>
              <div class="product-link">
                <div class="product-button"> <a href="#" title="Add to cart" class="AddToCart" data-product-id="<?php echo $productfirstrow->product_id; ?>" data-variant ="<?php echo $variant; ?>" data-qty="<?php echo $productfirstrow->quantity; ?>" data-variant-yes="<?php echo $variant_yes; ?>"><i class="fa fa-shopping-cart"></i>Add to cart</a> </div>
                <div class="add-to-link">
                  <ul>
                    <li><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" title="Details"><i class="fa fa-external-link"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php } ?>
         
          </div>
        </div>
        <div class="tab-pane fade" id="Suspense">
          <div class="tab-active owl-carousel"> 
     <?php  
     
     $related = $commanmodel->all_multiple_query_order_by_limit_with_like('product',array('product_status' => 'Active'),array('product_category' => 4),'product_id','DESC',10);  
            
              foreach($related as $productfirstrow) {   $pro_variant = $commanmodel->all_multiple_query_order_by('pro_variant',array('variant_pro_id' => $productfirstrow->product_id),'pro_variant_id','ASC');
                    
                     $variant =  ($pro_variant)?$pro_variant[0]->varian:'';

                 $variant_yes =  ($pro_variant)?'Yes':'No';

                            ?>
            <div class="product-wrapper">
              <div class="product-img"> <a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"> 
              <img src="<?php echo base_url('assets/images/'); ?>/<?php echo $productfirstrow->product_thumbnail; ?>" alt="<?php echo $productfirstrow->product_name; ?>" class="primary" /> </a>
                <div class="quick-view"> <a class="action-view" href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" data-bs-target="#productModal" data-bs-toggle="modal" title="Quick View"> <i class="fa fa-search-plus"></i> </a> </div>
                <div class="product-flag">
                  <ul>
                    
                    
                  </ul>
                </div>
              </div>
              <div class="product-details text-center">
                <h4><a href="#"><?php echo $productfirstrow->product_name; ?></a></h4>
                <div class="product-price">
                  <ul>
                    <li>₹ <?php echo $productfirstrow->product_price; ?></li>
                  </ul>
                </div>
              </div>
              <div class="product-link">
                <div class="product-button"> <a href="#" title="Add to cart" class="AddToCart" data-product-id="<?php echo $productfirstrow->product_id; ?>" data-variant ="<?php echo $variant; ?>" data-qty="<?php echo $productfirstrow->quantity; ?>" data-variant-yes="<?php echo $variant_yes; ?>"><i class="fa fa-shopping-cart"></i>Add to cart</a> </div>
                <div class="add-to-link">
                  <ul>
                    <li><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" title="Details"><i class="fa fa-external-link"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php } ?>
           
          </div>
        </div>
        <div class="tab-pane fade" id="Adventure">
          <div class="tab-active owl-carousel"> 
     <?php  
     
     $related = $commanmodel->all_multiple_query_order_by_limit_with_like('product',array('product_status' => 'Active'),array('product_category' => 6),'product_id','DESC',10);  
            
              foreach($related as $productfirstrow) {   $pro_variant = $commanmodel->all_multiple_query_order_by('pro_variant',array('variant_pro_id' => $productfirstrow->product_id),'pro_variant_id','ASC');
                    
                     $variant =  ($pro_variant)?$pro_variant[0]->varian:'';

                 $variant_yes =  ($pro_variant)?'Yes':'No';

                            ?>
            <div class="product-wrapper">
              <div class="product-img"> <a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"> 
              <img src="<?php echo base_url('assets/images/'); ?>/<?php echo $productfirstrow->product_thumbnail; ?>" alt="<?php echo $productfirstrow->product_name; ?>" class="primary" /> </a>
                <div class="quick-view"> <a class="action-view" href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" data-bs-target="#productModal" data-bs-toggle="modal" title="Quick View"> <i class="fa fa-search-plus"></i> </a> </div>
                <div class="product-flag">
                  <ul>
                    
                    
                  </ul>
                </div>
              </div>
              <div class="product-details text-center">
                <h4><a href="#"><?php echo $productfirstrow->product_name; ?></a></h4>
                <div class="product-price">
                  <ul>
                    <li>₹ <?php echo $productfirstrow->product_price; ?></li>
                  </ul>
                </div>
              </div>
              <div class="product-link">
                <div class="product-button"> <a href="#" title="Add to cart" class="AddToCart" data-product-id="<?php echo $productfirstrow->product_id; ?>" data-variant ="<?php echo $variant; ?>" data-qty="<?php echo $productfirstrow->quantity; ?>" data-variant-yes="<?php echo $variant_yes; ?>"><i class="fa fa-shopping-cart"></i>Add to cart</a> </div>
                <div class="add-to-link">
                  <ul>
                    <li><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" title="Details"><i class="fa fa-external-link"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php } ?>
         
          </div>
        </div>
        <div class="tab-pane fade" id="Supernatural">
          <div class="tab-active owl-carousel"> 
       <?php 
       
       $related = $commanmodel->all_multiple_query_order_by_limit_with_like('product',array('product_status' => 'Active'),array('product_category' => 10),'product_id','DESC',10);  
            
              foreach($related as $productfirstrow) {   $pro_variant = $commanmodel->all_multiple_query_order_by('pro_variant',array('variant_pro_id' => $productfirstrow->product_id),'pro_variant_id','ASC');
                    
                     $variant =  ($pro_variant)?$pro_variant[0]->varian:'';

                 $variant_yes =  ($pro_variant)?'Yes':'No';

                            ?>
            <div class="product-wrapper">
              <div class="product-img"> <a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"> 
              <img src="<?php echo base_url('assets/images/'); ?>/<?php echo $productfirstrow->product_thumbnail; ?>" alt="<?php echo $productfirstrow->product_name; ?>" class="primary" /> </a>
                <div class="quick-view"> <a class="action-view" href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" data-bs-target="#productModal" data-bs-toggle="modal" title="Quick View"> <i class="fa fa-search-plus"></i> </a> </div>
                <div class="product-flag">
                  <ul>
                    
                    
                  </ul>
                </div>
              </div>
              <div class="product-details text-center">
                <h4><a href="#"><?php echo $productfirstrow->product_name; ?></a></h4>
                <div class="product-price">
                  <ul>
                    <li>₹ <?php echo $productfirstrow->product_price; ?></li>
                  </ul>
                </div>
              </div>
              <div class="product-link">
                <div class="product-button"> <a href="#" title="Add to cart" class="AddToCart" data-product-id="<?php echo $productfirstrow->product_id; ?>" data-variant ="<?php echo $variant; ?>" data-qty="<?php echo $productfirstrow->quantity; ?>" data-variant-yes="<?php echo $variant_yes; ?>"><i class="fa fa-shopping-cart"></i>Add to cart</a> </div>
                <div class="add-to-link">
                  <ul>
                    <li><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" title="Details"><i class="fa fa-external-link"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php } ?>
         
          </div>
        </div>
        <div class="tab-pane fade" id="Indian">
          <div class="tab-active owl-carousel"> 
              <?php
              
              $related = $commanmodel->all_multiple_query_order_by_limit_with_like('product',array('product_status' => 'Active'),array('product_category' => 11),'product_id','DESC',10);  
            
              foreach($related as $productfirstrow) {   $pro_variant = $commanmodel->all_multiple_query_order_by('pro_variant',array('variant_pro_id' => $productfirstrow->product_id),'pro_variant_id','ASC');
                    
                     $variant =  ($pro_variant)?$pro_variant[0]->varian:'';

                 $variant_yes =  ($pro_variant)?'Yes':'No';

                            ?>
            <div class="product-wrapper">
              <div class="product-img"> <a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"> 
              <img src="<?php echo base_url('assets/images/'); ?>/<?php echo $productfirstrow->product_thumbnail; ?>" alt="<?php echo $productfirstrow->product_name; ?>" class="primary" /> </a>
                <div class="quick-view"> <a class="action-view" href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" data-bs-target="#productModal" data-bs-toggle="modal" title="Quick View"> <i class="fa fa-search-plus"></i> </a> </div>
              
              </div>
              <div class="product-details text-center">
                <h4><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"><?php echo $productfirstrow->product_name; ?></a></h4>
                <div class="product-price">
                  <ul>
                    <li>₹ <?php echo $productfirstrow->product_price; ?></li>
                  </ul>
                </div>
              </div>
              <div class="product-link">
                <div class="product-button"> <a href="#" title="Add to cart" class="AddToCart" data-product-id="<?php echo $productfirstrow->product_id; ?>" data-variant ="<?php echo $variant; ?>" data-qty="<?php echo $productfirstrow->quantity; ?>" data-variant-yes="<?php echo $variant_yes; ?>"><i class="fa fa-shopping-cart"></i>Add to cart</a> </div>
                <div class="add-to-link">
                  <ul>
                    <li><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" title="Details"><i class="fa fa-external-link"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php } ?>
           
          
          </div>
        </div>
      </div>
    </div>
    <div style="margin-bottom: 50px">
      <div class="col-lg-12">
        <h3 class="text-center">Non-Fiction Books</h3>
        <!-- tab-menu-start -->
        <div class="tab-menu mb-40 text-center">
          <ul class="nav justify-content-center">
            <li><a class="active" href="#Self" data-bs-toggle="tab">Self-Help </a></li>
            <li><a href="#Inspirational" data-bs-toggle="tab">Inspirational</a></li>
          </ul>
        </div>
      </div>
      <div class="tab-content">
        <div class="tab-pane fade show active" id="Self">
          <div class="tab-active owl-carousel"> 
         <?php 
         
         $related = $commanmodel->all_multiple_query_order_by_limit_with_like('product',array('product_status' => 'Active'),array('product_category' => 8),'product_id','DESC',10);  
            
              foreach($related as $productfirstrow) {   $pro_variant = $commanmodel->all_multiple_query_order_by('pro_variant',array('variant_pro_id' => $productfirstrow->product_id),'pro_variant_id','ASC');
                    
                     $variant =  ($pro_variant)?$pro_variant[0]->varian:'';

                 $variant_yes =  ($pro_variant)?'Yes':'No';

                            ?>
            <div class="product-wrapper">
              <div class="product-img"> <a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"> 
              <img src="<?php echo base_url('assets/images/'); ?>/<?php echo $productfirstrow->product_thumbnail; ?>" alt="<?php echo $productfirstrow->product_name; ?>" class="primary" /> </a>
                <div class="quick-view"> <a class="action-view" href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" title="Quick View"> <i class="fa fa-search-plus"></i> </a> </div>
              
              </div>
              <div class="product-details text-center">
                <h4><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"><?php echo $productfirstrow->product_name; ?></a></h4>
                <div class="product-price">
                  <ul>
                    <li>₹ <?php echo $productfirstrow->product_price; ?></li>
                  </ul>
                </div>
              </div>
              <div class="product-link">
                <div class="product-button"> <a href="#" title="Add to cart" class="AddToCart" data-product-id="<?php echo $productfirstrow->product_id; ?>" data-variant ="<?php echo $variant; ?>" data-qty="<?php echo $productfirstrow->quantity; ?>" data-variant-yes="<?php echo $variant_yes; ?>"><i class="fa fa-shopping-cart"></i>Add to cart</a> </div>
                <div class="add-to-link">
                  <ul>
                    <li><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" title="Details"><i class="fa fa-external-link"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php } ?>
          
          </div>
        </div>
        <div class="tab-pane fade" id="Inspirational">
          <div class="tab-active owl-carousel"> 
          <?php  
          $related = $commanmodel->all_multiple_query_order_by_limit_with_like('product',array('product_status' => 'Active'),array('product_category' => 9),'product_id','DESC',10);  
            
              foreach($related as $productfirstrow) {   $pro_variant = $commanmodel->all_multiple_query_order_by('pro_variant',array('variant_pro_id' => $productfirstrow->product_id),'pro_variant_id','ASC');
                    
                     $variant =  ($pro_variant)?$pro_variant[0]->varian:'';

                 $variant_yes =  ($pro_variant)?'Yes':'No';

                            ?>
            <div class="product-wrapper">
              <div class="product-img"> <a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"> 
              <img src="<?php echo base_url('assets/images/'); ?>/<?php echo $productfirstrow->product_thumbnail; ?>" alt="<?php echo $productfirstrow->product_name; ?>" class="primary" /> </a>
                <div class="quick-view"> <a class="action-view" href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"  title="Quick View"> <i class="fa fa-search-plus"></i> </a> </div>
               
              </div>
              <div class="product-details text-center">
                <h4><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>"><?php echo $productfirstrow->product_name; ?></a></h4>
                <div class="product-price">
                  <ul>
                    <li>₹ <?php echo $productfirstrow->product_price; ?></li>
                  </ul>
                </div>
              </div>
              <div class="product-link">
                <div class="product-button"> <a href="#" title="Add to cart" class="AddToCart" data-product-id="<?php echo $productfirstrow->product_id; ?>" data-variant ="<?php echo $variant; ?>" data-qty="<?php echo $productfirstrow->quantity; ?>" data-variant-yes="<?php echo $variant_yes; ?>"><i class="fa fa-shopping-cart"></i>Add to cart</a> </div>
                <div class="add-to-link">
                  <ul>
                    <li><a href="<?php echo base_url('book-details'); ?>/<?php echo $productfirstrow->slug; ?>" title="Details"><i class="fa fa-external-link"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php } ?>
          
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
