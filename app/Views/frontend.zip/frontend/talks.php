

<?php 
use App\Models\Commanmodel;
 $commanmodel = new Commanmodel();

    $poet  = $commanmodel->all_multiple_query_order_by('clients',array('client_status' => 'Active','type' => 'Poet'),'client_id','ASC');
   
    $gallery = $commanmodel->all_multiple_query_order_by('clients',array('client_status' => 'Active','type' => 'Gallery'),'client_id','ASC');
?>

<?php $about= $commanmodel->get_single_query('cms_pages',array('cms_id' => 15)); ?>
<div class="breadcrumbs-area mb-50">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="breadcrumbs-menu">
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#" class="active"><?php echo $about->cms_page_heading; ?></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- breadcrumbs-area-end --> 
<!-- about-main-area-start -->
<div class="about-main-area mb-70">
  <div class="container">
    <div class="row">
   
      <div class="col-lg-12 col-md-12 col-12">
        <div class="about-content">
          <?php echo $about->cms_page_description; ?>

<div class="gap20"></div>

<div class="new-book-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title bt text-center pt-50 mb-30 section-title-res">
                        <h2>Gallery of Past Talks</h2>
                    </div>
                </div>
            </div>
            <div class="tab-active owl-carousel">
                
                   <?php foreach($gallery as $gallery) { ?>
           <div class="tab-total">
                    <div class="product-wrapper mb-40">
                        <div class="product-img">
                            <a href="#">
                                <img src="<?=  base_url('assets/client/' . $gallery->client_image); ?>" alt="book" class="primary" />
                            </a>
                        </div>
                     
                    </div>
                </div>
          <?php } ?>
       
           



            </div>
        </div>
    </div>




        </div>
      </div>
    </div>
  </div>
</div>
